import { useRef, useMemo, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { DragControls, RoundedBox, Edges } from '@react-three/drei';
import * as THREE from 'three';

const CUBE_SIZE = 1.2;
const SPACING = 1.6;

export function Scene() {
  const [isDragging, setIsDragging] = useState(false);
  const animTime = useRef(0);

  // Generate a tile texture for the cubes (smooth border, grainy center)
  const tileTexture = useMemo(() => {
    const canvas = document.createElement('canvas');
    const size = 512;
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext('2d');
    if (context) {
      // 1. Fill entire canvas with white (smooth border)
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, size, size);

      // 2. Define the inner rounded rect
      const margin = 40;
      const radius = 30;
      
      context.beginPath();
      context.moveTo(margin + radius, margin);
      context.lineTo(size - margin - radius, margin);
      context.arcTo(size - margin, margin, size - margin, margin + radius, radius);
      context.lineTo(size - margin, size - margin - radius);
      context.arcTo(size - margin, size - margin, size - margin - radius, size - margin, radius);
      context.lineTo(margin + radius, size - margin);
      context.arcTo(margin, size - margin, margin, size - margin - radius, radius);
      context.lineTo(margin, margin + radius);
      context.arcTo(margin, margin, margin + radius, margin, radius);
      context.closePath();
      
      context.save();
      context.clip();

      // 3. Generate noise on an offscreen canvas
      const offscreen = document.createElement('canvas');
      offscreen.width = size;
      offscreen.height = size;
      const offCtx = offscreen.getContext('2d');
      if (offCtx) {
        const imgData = offCtx.createImageData(size, size);
        for (let i = 0; i < imgData.data.length; i += 4) {
          const noise = Math.random() * 100 + 50; // 50 to 150
          imgData.data[i] = noise;
          imgData.data[i+1] = noise;
          imgData.data[i+2] = noise;
          imgData.data[i+3] = 255;
        }
        offCtx.putImageData(imgData, 0, 0);
        context.drawImage(offscreen, 0, 0);
      }
      
      // 4. Add an inner shadow/bevel
      context.strokeStyle = '#aaaaaa';
      context.lineWidth = 20;
      context.stroke();
      context.strokeStyle = '#cccccc';
      context.lineWidth = 10;
      context.stroke();
      
      context.restore();
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.magFilter = THREE.LinearFilter;
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.generateMipmaps = true;
    texture.anisotropy = 16;
    return texture;
  }, []);

  // Generate initial positions for a 5x5x5 grid
  const cubes = useMemo(() => {
    const pos: THREE.Vector3[] = [];
    for (let x = -2; x <= 2; x++) {
      for (let y = -2; y <= 2; y++) {
        for (let z = -2; z <= 2; z++) {
          // Skip some cubes to make it look more organic like the video
          if (Math.random() > 0.5) continue;
          
          pos.push(
            new THREE.Vector3(
              x * SPACING + (Math.random() - 0.5) * 0.5,
              y * SPACING + (Math.random() - 0.5) * 0.5,
              z * SPACING + (Math.random() - 0.5) * 0.5
            )
          );
        }
      }
    }
    // Ensure we have at least some cubes
    if (pos.length < 10) {
      for (let i = 0; i < 10 - pos.length; i++) {
        pos.push(new THREE.Vector3((Math.random() - 0.5) * 3, (Math.random() - 0.5) * 3, (Math.random() - 0.5) * 3));
      }
    }
    return pos;
  }, []);

  useFrame((state, delta) => {
    animTime.current += delta * 0.12; // Speed of the loop (slowed down)
    
    const t = animTime.current;
    
    const baseRadius = 15;
    
    // 1. Z-axis / distance oscillation (moves in and out) - smoother
    const radius = baseRadius + Math.sin(t * 0.5) * 2;
    
    // 2. Continuous rotation around the Y axis (xy-plane equivalent in 3D)
    const theta = t;
    
    // 3. Diagonal/elevation oscillation (moves up and down) - more pronounced
    const phi = Math.sin(t * 0.8) * 0.8;
    
    // Convert Spherical coordinates to Cartesian for the camera
    state.camera.position.x = radius * Math.cos(phi) * Math.sin(theta);
    state.camera.position.y = radius * Math.sin(phi);
    state.camera.position.z = radius * Math.cos(phi) * Math.cos(theta);
    
    // Always look at the center of the structure
    state.camera.lookAt(0, 0, 0);
  });

  return (
    <group>
      {cubes.map((pos, i) => (
        <InteractiveCube key={i} position={pos} setIsDragging={setIsDragging} texture={tileTexture} />
      ))}
    </group>
  );
}

function InteractiveCube({ position, setIsDragging, texture }: { position: THREE.Vector3, setIsDragging: (dragging: boolean) => void, texture: THREE.Texture }) {
  const ref = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [dragged, setDragged] = useState(false);
  const [localPos, setLocalPos] = useState(position);

  // Floating animation offset so they don't all wobble identically
  const randomOffset = useMemo(() => Math.random() * Math.PI * 2, []);

  useFrame((state) => {
    if (ref.current) {
      // 1. Max bound for dragging
      const limit = 8;
      ref.current.position.x = THREE.MathUtils.clamp(ref.current.position.x, -limit, limit);
      ref.current.position.y = THREE.MathUtils.clamp(ref.current.position.y, -limit, limit);
      ref.current.position.z = THREE.MathUtils.clamp(ref.current.position.z, -limit, limit);

      if (!dragged) {
        const t = state.clock.getElapsedTime() + randomOffset;
        // Slight rotation wobble
        ref.current.rotation.x = Math.sin(t * 0.5) * 0.1;
        ref.current.rotation.y = Math.cos(t * 0.5) * 0.1;
      }
    }
  });

  return (
    <DragControls
      onDragStart={() => {
        setDragged(true);
        setIsDragging(true);
        document.body.style.cursor = 'grabbing';
      }}
      onDragEnd={() => {
        setDragged(false);
        setIsDragging(false);
        document.body.style.cursor = hovered ? 'grab' : 'auto';
        if (ref.current) {
          setLocalPos(ref.current.position.clone());
        }
      }}
    >
      <RoundedBox
        ref={ref}
        position={localPos}
        args={[CUBE_SIZE, CUBE_SIZE, CUBE_SIZE]}
        radius={0.15}
        smoothness={4}
        onPointerOver={() => {
          setHovered(true);
          if (!dragged) document.body.style.cursor = 'grab';
        }}
        onPointerOut={() => {
          setHovered(false);
          if (!dragged) document.body.style.cursor = 'auto';
        }}
      >
        <meshPhysicalMaterial
          color="#0070F3"
          transmission={0.85}
          ior={1.15}
          thickness={1.5}
          attenuationColor="#0011cc"
          attenuationDistance={2}
          metalness={0.1}
          roughness={0.05}
          clearcoat={1}
          clearcoatRoughness={0.1}
          iridescence={0.5}
          iridescenceIOR={1.2}
          iridescenceThicknessRange={[100, 400]}
          bumpMap={texture}
          bumpScale={0.03}
          transparent={true}
          opacity={1}
        />
        <Edges scale={1.0} threshold={15}>
          <lineBasicMaterial color="#00ffff" transparent opacity={0.8} />
        </Edges>
      </RoundedBox>
    </DragControls>
  );
}
